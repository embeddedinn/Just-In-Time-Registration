import json
import urllib.request
import time
from jose import jwk, jwt
from jose.utils import base64url_decode
import logging
import copy

logger = logging.getLogger()
logger.setLevel(logging.INFO)

import boto3
client = boto3.client('iot')

import os

ACCOUNT_ID = ""
region = os.environ['AWS_REGION']

#def checkUserPolicy:
#    pass
#
def updateUserPolicy(userPrincipal,deviceName):
    policy={
        "Version": "2012-10-17",
        "Statement": [
            {"Effect": "Allow",
            "Action": "iot:Connect",
            "Resource": "*"
            },
            {"Effect": "Allow",
            "Action":["iot:Publish",
                "iot:Subscribe",
                "iot:Receive",
                "iot:GetThingShadow",
                "iot:UpdateThingShadow",
                "iot:DeleteThingShadow"],
            "Resource": ["*",
                         "arn:aws:iot:"+region+":"+ACCOUNT_ID+":topicfilter/"+deviceName+"/*",
                         "arn:aws:iot:"+region+":"+ACCOUNT_ID+":topicfilter/$aws/things/"+deviceName+"/shadow/*"
                        ]
            }
        ]
    }
    policyDocument=json.dumps(policy)
    policyName=userPrincipal.split(":")[1]
    
    #get Current policy if exists
    currentPolicyDocument={}
    try:
        response = client.get_policy(policyName=policyName)
        currentPolicyDocument=copy.deepcopy(json.loads(response["policyDocument"]))
    except:
        pass
    
    logger.info("current policy is")
    logger.info(currentPolicyDocument)
    
    #if there is a policy , merge and create a new policy document
    if bool(currentPolicyDocument):
        logger.info("a policy already exists")
        logger.info(currentPolicyDocument)
        
        policyDocument=copy.deepcopy(currentPolicyDocument)
        policyDocument["Statement"][1]["Resource"].append("arn:aws:iot:"+region+":"+ACCOUNT_ID+":topic/"+deviceName+"/*")
        policyDocument["Statement"][1]["Resource"].append("arn:aws:iot:"+region+":"+ACCOUNT_ID+":topic/$aws/things/"+deviceName+"/shadow/*")
        policyDocument["Statement"][1]["Resource"]=list(set(policyDocument["Statement"][1]["Resource"]))        
        policyDocument=json.dumps(policyDocument)
    
    #detach policy from user
    try:
        response = client.detach_principal_policy( policyName=policyName,principal=userPrincipal)
    except:
        #assuming all is well
        pass

    #delete policy
    try:
        response = client.response = client.delete_policy( policyName=policyName)
    except:
        #assuming all is well
        pass
    
    try:
        response = client.create_policy(policyName=policyName, policyDocument=policyDocument)
        #logger.info(response)
    except:
        logging.error("Failed to update policy")
        return False
    
    try:
        response=client.attach_policy(policyName=policyName,target=userPrincipal)
        return True
    except:
        logging.error("Failed to attach policy")
        return False
    
    
userpool_id = 'us-east-1_d2G5VS3h4'

#validate the JWT passed by the user
def validateToken(token):
    global region
    global userpool_id
    app_client_id = '4nhjqtd3a3kdcp72i49klg6o0f'
    keys_url = 'https://cognito-idp.{}.amazonaws.com/{}/.well-known/jwks.json'.format(region, userpool_id)
    # instead of re-downloading the public keys every time
    # we download them only on cold start
    # https://aws.amazon.com/blogs/compute/container-reuse-in-lambda/
    with urllib.request.urlopen(keys_url) as url:
        response= url.read()
    
    keys = json.loads(response)['keys']

    # get the kid from the headers prior to verification
    headers = jwt.get_unverified_headers(token)
    kid = headers['kid']
    # search for the kid in the downloaded public keys
    key_index = -1
    for i in range(len(keys)):
        if kid == keys[i]['kid']:
            key_index = i
            break
    if key_index == -1:
        logger.error('Public key not found in jwks.json')
        return False
    # construct the public key
    public_key = jwk.construct(keys[key_index])
    # get the last two sections of the token,
    # message and signature (encoded in base64)
    message, encoded_signature = str(token).rsplit('.', 1)
    # decode the signature
    decoded_signature = base64url_decode(encoded_signature.encode('utf-8'))
    # verify the signature
    if not public_key.verify(message.encode("utf8"), decoded_signature):
        logger.error('Signature verification failed')
        return False
    print('Signature successfully verified')
    # since we passed the verification, we can now safely
    # use the unverified claims
    claims = jwt.get_unverified_claims(token)
    # additionally we can verify the token expiration
    if time.time() > claims['exp']:
        logger.error('Token is expired')
        return False
    # and the Audience  (use claims['client_id'] if verifying an access token)
    if claims['aud'] != app_client_id:
        logger.error('Token was not issued for this audience')
        return False
    # now we can use the claims
    logger.info(claims)
    return claims

#enter user attribute of the thing and assign this thing to the user
def attachDeviceToUser(deviceName,user,friendlyName):
    response = client.update_thing(
                            thingName=deviceName,
                            attributePayload={'attributes':{'user':user,"friendlyName":friendlyName},"merge":True},
                            thingTypeName="genType")
    return True
    

#check if the a device exists and/or already registered to a user
def checkDeviceExist(deviceName):
    response = client.list_things(attributeName="thingName",attributeValue=deviceName)
    #logger.info(response)
    if not bool(response["things"]):
        logger.info("Thing not found")
        return False
    elif "user" in response["things"][0]["attributes"]:
        logger.info("Thing already registered to "+response["things"][0]["attributes"]["user"])
        return False
    else:
        return True

#check if the principal passed matches the token passed in request
def validateUserPrincipal(userPrincipal,sessionID):
    client = boto3.client('cognito-identity')
    try :
        response = client.get_credentials_for_identity(IdentityId=userPrincipal,Logins={
            'cognito-idp.'+region+'.amazonaws.com/'+userpool_id :sessionID
        })
        return True
    except :
        return False


def handler(event, context):
    logger.info("got event "+json.dumps(event))
    global ACCOUNT_ID
    ACCOUNT_ID=context.invoked_function_arn.split(":")[4]
    
    #sessionID=event["sessionID"].strip()
    sessionID=event["params"]["header"]["auth-token"]
    deviceName=event["body-json"]["deviceSerial"].strip()
    userPrincipal=event["body-json"]["principal"].strip()
    friendlyName=event["body-json"]["deviceFriendlyName"].strip()
    
    #if device doesnot exist or is already registered, exit here. 
    # for security reason, tell that the device is already registered.
    if not checkDeviceExist(deviceName.strip()):
        return {
        'statusCode': 200,
        'body': {"Error":True,"ErrorMessage":"Device already registered"}
        }
    
    else:
        claims=validateToken(sessionID)
    
    if not claims:
        return {
        'statusCode': 200,
        'body': {"Error":True,"ErrorMessage":"unauthorized"}
        }
    elif not validateUserPrincipal(userPrincipal,sessionID):
            return {
                'statusCode': 200,
                'body': {"Error":True,"ErrorMessage":"Unauthorized"}
            }    
    else:
        userEmail=claims["email"].strip()
        attachDeviceToUser(deviceName.strip(),userEmail,friendlyName)
        
    if not updateUserPolicy(userPrincipal,deviceName):
        return {
                'statusCode': 200,
                'body': {"Error":True,"ErrorMessage":"Policy Failure"}
            }
    else:
        return {
            'statusCode': 200,
            'body':{}
        }