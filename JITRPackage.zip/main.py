import logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

import json
import OpenSSL

import boto3
client = boto3.client('iot')

region = "us-east-1"
accountId = ""

certificateARN = ""
#var iot = new AWS.Iot({'region': region, apiVersion: '2015-05-28'});
certificateId = ""
#existing policy name for all devices
policyName = "devicePolicy"

#Get commonName from device certificate
def getCertCN(cert):
	certBytes=bytes(cert, 'utf-8')
	cert=OpenSSL.crypto.load_certificate( OpenSSL.crypto.FILETYPE_PEM, certBytes)
	nameComponents=cert.get_subject().get_components()
	for name,value in nameComponents:
		if "CN"==name.decode("utf-8") :
			return value.decode("utf-8") 
	
	return False


#Policy that allows connect, publish, subscribe and receive
def getPolicy(accountId,certificateId):
	global region
	topicName = "foo/bar"
	policy={"Version": "2012-10-17",
			"Statement": [
			{
			"Effect": "Allow",
			"Action": 	"iot:Connect",
			"Resource": "*",
			"Condition":{  
            "Bool":{  
                "iot:Connection.Thing.IsAttached":["true"]
            }
			}
			},
			{
			"Effect": "Allow",
			"Action": [
			"iot:Publish",
			"iot:Receive",
			"iot:Subscribe"
			],
			"Resource": "arn:aws:iot:"+region+":"+accountId+":topic/"+topicName+"/${iot:Connection.Thing.ThingName}/*"
			}
			]
			}
	return json.dumps(policy)
	


def handler (event,context):
	logger.info('got event{}'.format(event))
	global accountId
	accountId = str(event["awsAccountId"]).strip()
	global certificateId
	certificateId = str(event["certificateId"]).strip()
	certificateARN = "arn:aws:iot:"+region+":"+accountId+":cert/"+certificateId
	
	global policyName
	#policyName = "Policy_"+certificateId;
	#policyDocument=getPolicy(accountId,certificateId)	
	#response = client.create_policy(policyName=policyName,policyDocument=policyDocument)
	#logger.info(response)
    	
	#attach device policy to certificate
	response=client.attach_policy(policyName=policyName,target=certificateARN)
	logger.info(response)

	#get thing name from certifiate CN
	response=client.describe_certificate(certificateId=certificateId)
	deviceName=getCertCN(response["certificateDescription"]["certificatePem"])
	if ( not deviceName) or (not deviceName.strip()):
		return (-1)	
	logger.info(deviceName)
		
	response = client.create_thing(
		thingName=deviceName,
		thingTypeName="embeddedinn",
		attributePayload= {'attributes':{'thingName':deviceName}}
	)
	logger.info(response)
	
	#attach thing to certificate
	response = client.attach_thing_principal(thingName=deviceName,principal=certificateARN)
	
	
	# activate certificate
	response=client.update_certificate(certificateId=certificateId,newStatus="ACTIVE")
	logger.info(response)
	
	return;
	